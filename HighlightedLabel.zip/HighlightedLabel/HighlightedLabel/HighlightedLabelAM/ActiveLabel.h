//
//  ActiveLabel.h
//  ActiveLabel
//
//  Created by Johannes Schickling on 9/4/15.
//  Copyright © 2015 Optonaut. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ActiveLabel.
FOUNDATION_EXPORT double ActiveLabelVersionNumber;

//! Project version string for ActiveLabel.
FOUNDATION_EXPORT const unsigned char ActiveLabelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ActiveLabel/PublicHeader.h>


